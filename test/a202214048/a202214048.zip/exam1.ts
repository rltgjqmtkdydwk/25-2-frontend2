type Person = {
  name: string;
  age: number;
};

function createPerson(name: string, age: number): Person {
  return { name, age };
}

const { name : pname, age } = createPerson("홍길동", 16);

console.log(`${pname}  ${age}`);
